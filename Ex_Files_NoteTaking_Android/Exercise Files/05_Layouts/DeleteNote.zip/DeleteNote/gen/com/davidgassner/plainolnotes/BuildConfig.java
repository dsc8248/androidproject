/** Automatically generated file. DO NOT MODIFY */
package com.davidgassner.plainolnotes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}