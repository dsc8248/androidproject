package com.davidgassner.plainolnotes.data;

import java.util.ArrayList;
import java.util.List;

public class NotesDataSource {

	public List<NoteItem> findAll() {
		
		List<NoteItem> noteList = new ArrayList<NoteItem>();
		NoteItem note = NoteItem.getNew();
		noteList.add(note);
		return noteList;
		
	}
	
	public boolean update(NoteItem note) {
		return true;
	}
	
	public boolean remove(NoteItem note) {
		return true;
	}
	
	
}
